"""Typed, offline-first configuration for Aerostacks services."""

from pydantic import Field

from ._model import (
    ComponentPolicy,
    ConfigError,
    Reload,
    describe_service,
    live,
    restart,
)
from ._service import SDK_VERSION, InstanceStatus, Restart, Service

__version__ = SDK_VERSION
__all__ = [
    "ComponentPolicy",
    "ConfigError",
    "Field",
    "InstanceStatus",
    "Reload",
    "Restart",
    "Service",
    "describe_service",
    "live",
    "restart",
]

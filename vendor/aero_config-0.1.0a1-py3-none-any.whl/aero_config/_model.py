"""Config model: reload policies, component introspection, registration payload."""

from __future__ import annotations

import dataclasses
import hashlib
import json
from dataclasses import dataclass
from enum import StrEnum
from typing import Annotated, Any, get_args, get_origin, get_type_hints

from pydantic import TypeAdapter


class ConfigError(Exception):
    """Raised for invalid config models or failed explicit server calls."""


class Reload(StrEnum):
    """How a component change is applied to a running service."""

    LIVE = "live"
    RESTART = "restart"


@dataclass(frozen=True)
class ComponentPolicy:
    """Per-component metadata. An empty title is humanized from the field name."""

    reload: Reload = Reload.LIVE
    title: str = ""
    description: str | None = None


def live(title: str | None = None, description: str | None = None) -> ComponentPolicy:
    """Policy: changes are applied to the running process."""
    return ComponentPolicy(Reload.LIVE, title or "", description)


def restart(
    title: str | None = None, description: str | None = None
) -> ComponentPolicy:
    """Policy: changes take effect after the service restarts."""
    return ComponentPolicy(Reload.RESTART, title or "", description)


@dataclass(frozen=True)
class Component:
    """One top-level field of the root config dataclass."""

    name: str
    type: type
    policy: ComponentPolicy
    adapter: TypeAdapter[Any]


def humanize(name: str) -> str:
    """`idle_watchdog` -> `Idle watchdog`."""
    text = name.replace("_", " ").strip()
    return text[:1].upper() + text[1:]


def introspect(root: type) -> dict[str, Component]:
    """Derive the components of a root dataclass type."""
    if not (isinstance(root, type) and dataclasses.is_dataclass(root)):
        raise ConfigError(f"root config {root!r} must be a dataclass")
    hints = get_type_hints(root, include_extras=True)
    out: dict[str, Component] = {}
    for f in dataclasses.fields(root):
        tp = hints[f.name]
        policy = live()
        if get_origin(tp) is Annotated:
            tp, *meta = get_args(tp)
            policy = next((m for m in meta if isinstance(m, ComponentPolicy)), policy)
        if not policy.title:
            policy = dataclasses.replace(policy, title=humanize(f.name))
        out[f.name] = Component(f.name, tp, policy, TypeAdapter(tp))
    return out


def seed_values(components: dict[str, Component], seed: Any = None) -> dict[str, Any]:
    """Typed default per component: from `seed` if given, else `comp_type()`."""
    values: dict[str, Any] = {}
    for name, comp in components.items():
        if seed is not None:
            values[name] = getattr(seed, name)
            continue
        try:
            values[name] = comp.type()
        except TypeError as e:
            raise ConfigError(
                f"component {name!r} ({comp.type!r}) is not constructible without "
                f"arguments ({e}); give its fields defaults or pass seed="
            ) from e
    return values


def describe_service(service: str, root: type, seed: Any = None) -> dict[str, Any]:
    """Build the registration payload for a root type (+ optional seed)."""
    comps = introspect(root)
    defaults = seed_values(comps, seed)
    components: dict[str, Any] = {}
    for name, c in comps.items():
        components[name] = {
            "title": c.policy.title,
            "description": c.policy.description,
            "reload": c.policy.reload.value,
            "schema": c.adapter.json_schema(),
            "default": c.adapter.dump_python(defaults[name], mode="json"),
        }
    hashed = {
        n: {k: v for k, v in c.items() if k != "default"} for n, c in components.items()
    }
    canonical = json.dumps(hashed, sort_keys=True, separators=(",", ":"))
    return {
        "service": service,
        "schema_hash": hashlib.sha256(canonical.encode()).hexdigest(),
        "components": components,
    }

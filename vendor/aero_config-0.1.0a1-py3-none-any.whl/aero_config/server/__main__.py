"""``python -m aero_config.server --db ./aero-config.db --port 8791``."""

from __future__ import annotations

import argparse


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="aero_config.server")
    parser.add_argument("--db", default="./aero-config.db", help="SQLite path")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8791)
    args = parser.parse_args(argv)

    import uvicorn

    from .app import create_app

    uvicorn.run(create_app(args.db), host=args.host, port=args.port)


if __name__ == "__main__":
    main()

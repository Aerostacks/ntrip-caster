/* aero-config UI: vanilla JS, no build step.
 * Every dynamic value goes through textContent / setAttribute (never innerHTML),
 * so nothing from the server or the user is ever parsed as HTML. */
"use strict";

// ---------------------------------------------------------------- helpers
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "text") el.textContent = v;
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, "");
    else el.setAttribute(k, String(v));
  }
  const add = (kid) => {
    if (kid === null || kid === undefined || kid === false) return;
    if (Array.isArray(kid)) kid.forEach(add);
    else el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  };
  kids.forEach(add);
  return el;
}

const enc = encodeURIComponent;
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
const humanize = (s) => String(s).replace(/[_-]+/g, " ").replace(/^./, (c) => c.toUpperCase());

function store(key, value) {
  try {
    if (value === undefined) return localStorage.getItem(key);
    localStorage.setItem(key, value);
  } catch (_) { /* storage unavailable */ }
  return null;
}

function relTime(iso) {
  if (!iso) return "never";
  const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
  if (Number.isNaN(s)) return String(iso);
  if (s < 5) return "just now";
  if (s < 60) return `${Math.round(s)}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}
const absTime = (iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? String(iso) : d.toLocaleString(); };

function toast(text, bad) {
  const el = h("div", { class: "toast" + (bad ? " bad" : ""), text });
  document.getElementById("toasts").append(el);
  setTimeout(() => el.remove(), bad ? 6000 : 2500);
}

async function api(path, opts) {
  const res = await fetch(path, opts);
  let body = null;
  if (res.status !== 204) {
    try { body = await res.json(); } catch (_) { body = null; }
  }
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

// ------------------------------------------------------- schema utilities
function deref(schema, root, depth = 0) {
  if (schema === true || schema === undefined || schema === null) return {};
  if (typeof schema !== "object" || depth > 20) return {};
  let out = schema;
  if (typeof out.$ref === "string") {
    const m = /^#\/(\$defs|definitions)\/(.+)$/.exec(out.$ref);
    const target = m && root && root[m[1]] ? root[m[1]][m[2].replace(/~1/g, "/").replace(/~0/g, "~")] : null;
    const { $ref, ...rest } = out;
    out = { ...deref(target, root, depth + 1), ...rest };
  }
  if (Array.isArray(out.allOf) && out.allOf.length === 1) {
    const { allOf, ...rest } = out;
    out = { ...deref(allOf[0], root, depth + 1), ...rest };
  }
  return out;
}

function nonNullBranches(schema, root) {
  const alts = schema.anyOf || schema.oneOf;
  if (!Array.isArray(alts)) return null;
  const resolved = alts.map((a) => deref(a, root));
  const nonNull = resolved.filter((a) => a.type !== "null");
  if (nonNull.length === resolved.length) return null; // not nullable
  return nonNull;
}

const PRIMITIVES = ["string", "integer", "number", "boolean"];
const typeOf = (s) => (Array.isArray(s.type) ? s.type.find((t) => t !== "null") : s.type);

function emptyValue(schema, root) {
  const s = deref(schema, root);
  if (s.default !== undefined) return clone(s.default);
  if (Array.isArray(s.enum)) return clone(s.enum[0]);
  if (s.const !== undefined) return clone(s.const);
  const branches = nonNullBranches(s, root);
  if (branches) return null;
  switch (typeOf(s)) {
    case "string": return "";
    case "integer": case "number": return s.minimum !== undefined ? s.minimum : 0;
    case "boolean": return false;
    case "array": return [];
    case "object": {
      const o = {};
      for (const [k, v] of Object.entries(s.properties || {})) o[k] = emptyValue(v, root);
      return o;
    }
    default: return null;
  }
}

function boundsHint(s) {
  const parts = [];
  if (s.minimum !== undefined) parts.push(`min ${s.minimum}`);
  if (s.exclusiveMinimum !== undefined) parts.push(`> ${s.exclusiveMinimum}`);
  if (s.maximum !== undefined) parts.push(`max ${s.maximum}`);
  if (s.exclusiveMaximum !== undefined) parts.push(`< ${s.exclusiveMaximum}`);
  if (s.multipleOf !== undefined) parts.push(`multiple of ${s.multipleOf}`);
  return parts.join(", ");
}

function showDefault(d) {
  if (d === undefined || d === null) return "";
  return typeof d === "object" ? JSON.stringify(d) : String(d);
}

// ---------------------------------------------------- error registry
// Maps dotted paths ("a.b.0") to error elements so server and client errors
// land next to the right field.
class Registry {
  constructor() { this.map = new Map(); }
  add(path, errEl, wrapEl) { this.map.set(path, { errEl, wrapEl }); }
  dropPrefix(path) {
    for (const k of [...this.map.keys()]) if (k.startsWith(path + ".")) this.map.delete(k);
  }
  clear() {
    for (const { errEl, wrapEl } of this.map.values()) {
      errEl.textContent = "";
      if (wrapEl) wrapEl.classList.remove("invalid");
    }
  }
  show(errors) {
    this.clear();
    const unmatched = [];
    for (const e of errors) {
      const parts = e.path === "" ? [] : String(e.path).split(".");
      let hit = null;
      for (let n = parts.length; n >= 0 && !hit; n--) hit = this.map.get(parts.slice(0, n).join("."));
      if (!hit) { unmatched.push(e); continue; }
      const prefix = e.path && !this.map.has(e.path) ? `${e.path}: ` : "";
      hit.errEl.textContent += (hit.errEl.textContent ? "\n" : "") + prefix + e.message;
      if (hit.wrapEl) hit.wrapEl.classList.add("invalid");
    }
    return unmatched;
  }
}

// ----------------------------------------------------------- the renderer
// buildField returns {el, get(errs)}; get collects client-side errors into
// `errs` (array of {path, message}) when provided and returns the value.
function buildField(schema, value, o) {
  const root = o.root;
  const s = deref(schema, root);
  const pathStr = o.path.join(".");
  const label = s.title || o.name || "";
  const desc = s.description;
  const push = (errs, message) => { if (errs) errs.push({ path: pathStr, message }); };
  const changed = o.onChange || (() => {});

  const frame = (control, hints) => {
    const errEl = h("div", { class: "err", role: "alert" });
    const wrap = h("div", { class: "field" },
      label ? h("label", { class: "lbl", text: label }) : null,
      control,
      desc || hints ? h("div", { class: "help", text: [desc, hints].filter(Boolean).join(" · ") }) : null,
      errEl);
    o.reg.add(pathStr, errEl, wrap);
    return wrap;
  };

  // nullable: anyOf [X, null]
  const branches = nonNullBranches(s, root);
  if (branches && branches.length === 1) {
    const innerSchema = { ...branches[0] };
    for (const k of ["title", "description", "default"]) if (s[k] !== undefined && innerSchema[k] === undefined) innerSchema[k] = s[k];
    const isNull = value === null || value === undefined;
    const inner = buildField(innerSchema, isNull ? emptyValue(innerSchema, root) : value, { ...o, name: o.name });
    const box = h("input", { type: "checkbox", "aria-label": `Set ${label || "value"}` });
    box.checked = !isNull;
    const holder = h("div", {}, inner.el);
    const stateEl = h("span", {});
    const sync = () => { holder.hidden = !box.checked; stateEl.textContent = (label ? label + ": " : "") + (box.checked ? "set" : "not set (null)"); };
    box.addEventListener("change", () => { sync(); changed(); });
    sync();
    const head = h("label", { class: "nullable-head" }, box, stateEl);
    return { el: h("div", { class: "nullable" }, head, holder), get: (errs) => (box.checked ? inner.get(errs) : null) };
  }

  // enum / const
  if (Array.isArray(s.enum) || s.const !== undefined) {
    const values = Array.isArray(s.enum) ? [...s.enum] : [s.const];
    const idx = values.findIndex((v) => JSON.stringify(v) === JSON.stringify(value));
    const labels = values.map((v) => (typeof v === "string" ? v : JSON.stringify(v)));
    if (idx < 0 && value !== undefined) { values.unshift(value); labels.unshift(`${JSON.stringify(value)} (current, not allowed)`); }
    const sel = h("select", { "aria-label": label || o.name }, labels.map((l, i) => h("option", { value: String(i), text: l })));
    sel.selectedIndex = Math.max(0, values.findIndex((v) => JSON.stringify(v) === JSON.stringify(value === undefined ? values[0] : value)));
    sel.addEventListener("change", changed);
    return { el: frame(sel), get: () => values[sel.selectedIndex] };
  }

  const type = typeOf(s);

  if (type === "boolean") {
    const input = h("input", { type: "checkbox", role: "switch" });
    input.checked = value === true;
    input.addEventListener("change", () => { txt.textContent = input.checked ? "On" : "Off"; changed(); });
    const txt = h("span", { class: "dim", text: input.checked ? "On" : "Off" });
    const control = h("div", { class: "inline" }, h("span", { class: "switch" }, input, h("span", { class: "track" })), txt);
    return { el: frame(control), get: () => input.checked };
  }

  if (type === "integer" || type === "number") {
    const input = h("input", {
      type: "number", step: type === "integer" ? "1" : "any", inputmode: "decimal",
      min: s.minimum, max: s.maximum, placeholder: showDefault(s.default), "aria-label": label || o.name,
    });
    if (typeof value === "number") input.value = String(value);
    input.addEventListener("input", changed);
    const hint = boundsHint(s);
    const get = (errs) => {
      const raw = input.value.trim();
      if (raw === "") { push(errs, "A number is required"); return undefined; }
      const n = Number(raw);
      let msg = null;
      if (!Number.isFinite(n)) msg = `"${raw}" is not a number`;
      else if (type === "integer" && !Number.isInteger(n)) msg = "Must be a whole number";
      else if (s.minimum !== undefined && n < s.minimum) msg = `Must be at least ${s.minimum}`;
      else if (s.maximum !== undefined && n > s.maximum) msg = `Must be at most ${s.maximum}`;
      else if (s.exclusiveMinimum !== undefined && n <= s.exclusiveMinimum) msg = `Must be greater than ${s.exclusiveMinimum}`;
      else if (s.exclusiveMaximum !== undefined && n >= s.exclusiveMaximum) msg = `Must be less than ${s.exclusiveMaximum}`;
      else if (s.multipleOf && Math.abs(n / s.multipleOf - Math.round(n / s.multipleOf)) > 1e-9) msg = `Must be a multiple of ${s.multipleOf}`;
      if (msg) { push(errs, msg); return Number.isFinite(n) ? n : undefined; }
      return n;
    };
    return { el: frame(input, hint), get };
  }

  if (type === "string") {
    const input = h("input", {
      type: "text", placeholder: showDefault(s.default), minlength: s.minLength, maxlength: s.maxLength,
      autocomplete: "off", spellcheck: "false", "aria-label": label || o.name,
    });
    input.value = typeof value === "string" ? value : "";
    input.addEventListener("input", changed);
    const hint = [s.minLength !== undefined ? `min length ${s.minLength}` : "", s.maxLength !== undefined ? `max length ${s.maxLength}` : "", s.pattern ? `pattern ${s.pattern}` : ""].filter(Boolean).join(", ");
    const get = (errs) => {
      const v = input.value;
      if (s.minLength !== undefined && v.length < s.minLength) push(errs, `Must be at least ${s.minLength} characters`);
      else if (s.maxLength !== undefined && v.length > s.maxLength) push(errs, `Must be at most ${s.maxLength} characters`);
      else if (s.pattern) {
        try { if (!new RegExp(s.pattern, "u").test(v)) push(errs, `Must match ${s.pattern}`); } catch (_) { /* server decides */ }
      }
      return v;
    };
    return { el: frame(input, hint), get };
  }

  if (type === "object" && isObj(s.properties) && Object.keys(s.properties).length) {
    const cur = isObj(value) ? value : {};
    const required = new Set(s.required || []);
    const kids = Object.entries(s.properties).map(([k, ps]) => {
      const sub = deref(ps, root);
      const v = cur[k] !== undefined ? cur[k] : (sub.default !== undefined ? sub.default : emptyValue(ps, root));
      return [k, buildField(ps, v, { ...o, path: [...o.path, k], name: humanize(k) })];
    });
    const errEl = h("div", { class: "err", role: "alert" });
    o.reg.add(pathStr, errEl, null);
    const fs = h("fieldset", { class: "obj" },
      label && o.path.length ? h("legend", { text: label }) : null,
      desc ? h("div", { class: "help", text: desc }) : null,
      kids.map(([, f]) => f.el), errEl);
    return {
      el: fs,
      get: (errs) => {
        const out = {};
        for (const [k, f] of kids) {
          const v = f.get(errs);
          if (v !== undefined || required.has(k)) out[k] = v;
        }
        return out;
      },
    };
  }

  if (type === "array" && s.items && !s.prefixItems && !Array.isArray(s.items)) {
    const itemSchema = s.items;
    const list = h("div", { class: "list" });
    const errEl = h("div", { class: "err", role: "alert" });
    let rows = [];
    const wrap = h("div", { class: "field" }, label ? h("span", { class: "lbl", text: label }) : null, list,
      h("button", { type: "button", class: "small", text: "+ Add item", onclick: () => addItem() }),
      desc || s.minItems !== undefined || s.maxItems !== undefined
        ? h("div", { class: "help", text: [desc, s.minItems !== undefined ? `min ${s.minItems} items` : "", s.maxItems !== undefined ? `max ${s.maxItems} items` : ""].filter(Boolean).join(" · ") })
        : null,
      errEl);
    o.reg.add(pathStr, errEl, wrap);
    function render(values) {
      o.reg.dropPrefix(pathStr);
      list.replaceChildren();
      rows = values.map((v, i) => {
        const node = buildField(itemSchema, v, { ...o, path: [...o.path, String(i)], name: "", onChange: changed });
        const rm = h("button", { type: "button", class: "icon danger", "aria-label": `Remove item ${i + 1}`, text: "✕", onclick: () => remove(i) });
        list.append(h("div", { class: "list-row" }, h("div", { class: "grow" }, node.el), rm));
        return node;
      });
    }
    function current() {
      return rows.map((n) => { const v = n.get(null); return v === undefined ? emptyValue(itemSchema, root) : v; });
    }
    function remove(i) { const vals = current(); vals.splice(i, 1); render(vals); changed(); }
    function addItem() { const vals = current(); vals.push(emptyValue(itemSchema, root)); render(vals); changed(); }
    render(Array.isArray(value) ? value : []);
    return {
      el: wrap,
      get: (errs) => {
        const out = rows.map((n) => n.get(errs));
        if (s.minItems !== undefined && out.length < s.minItems) push(errs, `Needs at least ${s.minItems} items`);
        if (s.maxItems !== undefined && out.length > s.maxItems) push(errs, `At most ${s.maxItems} items allowed`);
        return out;
      },
    };
  }

  // fallback: raw JSON
  const ta = h("textarea", { spellcheck: "false", "aria-label": label || o.name });
  ta.value = value === undefined ? "" : JSON.stringify(value, null, 2);
  ta.rows = Math.min(14, Math.max(3, ta.value.split("\n").length + 1));
  ta.addEventListener("input", changed);
  return {
    el: frame(ta, "JSON"),
    get: (errs) => {
      try { return JSON.parse(ta.value); } catch (e) { push(errs, `Invalid JSON: ${e.message}`); return undefined; }
    },
  };
}

// -------------------------------------------------------------- app state
const state = { services: [], service: null, instance: null, data: null, extra: {}, token: 0 };
const mainEl = () => document.getElementById("main");

function parseHash() {
  const m = /^#\/([^/]+)(?:\/(.+))?$/.exec(location.hash);
  if (!m) return { service: null, instance: null };
  return { service: decodeURIComponent(m[1]), instance: m[2] ? decodeURIComponent(m[2]) : null };
}
function setHash(service, instance) {
  const next = service ? `#/${enc(service)}${instance ? "/" + enc(instance) : ""}` : "";
  if (location.hash !== next) location.hash = next; else route();
}

async function loadServices() {
  try {
    state.services = await api("/api/services");
  } catch (e) {
    mainEl().replaceChildren(h("p", { class: "empty", text: `Cannot reach the server: ${e.message}` }));
    return;
  }
  const ul = document.getElementById("services");
  ul.replaceChildren(...state.services.map((svc) =>
    h("li", {}, h("button", {
      type: "button", "aria-current": svc.name === state.service ? "true" : "false",
      onclick: () => setHash(svc.name, null),
    }, svc.name, h("span", { class: "meta", text: `${svc.components.length} components · ${svc.instances.length} instances` })))));
  if (!state.services.length) ul.append(h("li", { class: "dim", text: "No services registered yet." }));
}

async function route() {
  const { service, instance } = parseHash();
  state.service = service;
  state.instance = instance;
  await loadServices();
  if (!service) {
    const first = state.services[0];
    if (first) { setHash(first.name, null); return; }
    mainEl().replaceChildren(h("p", { class: "empty", text: "Register a service (POST /api/services/{name}/register) to start editing." }));
    return;
  }
  await loadService();
}

async function loadService() {
  const token = ++state.token;
  let data;
  try {
    data = await api(`/api/services/${enc(state.service)}${state.instance ? `?instance=${enc(state.instance)}` : ""}`);
  } catch (e) {
    if (token !== state.token) return;
    mainEl().replaceChildren(h("p", { class: "empty", text: e.status === 404 ? `Unknown service "${state.service}".` : `Failed to load: ${e.message}` }));
    return;
  }
  if (token !== state.token) return;
  state.data = data;
  renderService();
}

function knownInstances() {
  const set = new Set((state.data?.instances || []).map((i) => i.instance));
  for (const n of state.extra[state.service] || []) set.add(n);
  if (state.instance) set.add(state.instance);
  return [...set].sort();
}

function renderService() {
  const { data } = state;
  const sel = h("select", { id: "instance-select", "aria-label": "Instance" },
    h("option", { value: "", text: "All instances (service default)" }),
    knownInstances().map((n) => h("option", { value: n, text: n })));
  sel.value = state.instance || "";
  sel.addEventListener("change", () => setHash(state.service, sel.value || null));
  const newInst = h("input", { type: "text", placeholder: "new instance name", "aria-label": "New instance name", style: "width:170px" });
  const addInst = () => {
    const name = newInst.value.trim();
    if (!name) return;
    if (name === "*") { toast("'*' is reserved", true); return; }
    (state.extra[state.service] ||= []).push(name);
    setHash(state.service, name);
  };
  newInst.addEventListener("keydown", (e) => { if (e.key === "Enter") addInst(); });

  const strip = h("div", { id: "strip" });
  const cards = Object.entries(data.components).map(([name, comp]) => makeCard(name, comp));
  mainEl().replaceChildren(
    h("div", { class: "page-head" },
      h("h1", { text: data.name }),
      h("div", { class: "dim", text: `registered ${relTime(data.registered_at)}` })),
    h("div", { class: "toolbar" }, h("label", { text: "Instance" }), sel, newInst,
      h("button", { type: "button", class: "small", text: "Add", onclick: addInst })),
    strip,
    ...cards.map((c) => c.el));
  renderStrip();
}

function renderStrip() {
  const strip = document.getElementById("strip");
  if (!strip) return;
  strip.replaceChildren();
  strip.className = "";
  if (!state.instance) return;
  const inst = (state.data?.instances || []).find((i) => i.instance === state.instance);
  strip.className = "strip";
  if (!inst || !inst.status) {
    strip.append(h("div", { class: "row" },
      h("span", { text: `Instance ${state.instance}: ` }),
      h("span", { class: "dim", text: inst?.last_seen ? `last seen ${relTime(inst.last_seen)}, no status reported yet` : "never seen, no status reported yet" })));
    return;
  }
  const st = inst.status;
  const behind = st.latest_version && st.applied_version !== st.latest_version;
  strip.append(
    h("div", { class: "row" },
      h("span", {}, h("span", { class: "k", text: "last seen " }), h("span", { title: absTime(inst.last_seen), text: relTime(inst.last_seen) })),
      h("span", {}, h("span", { class: "k", text: "source " }), String(st.source ?? "?")),
      h("span", {}, h("span", { class: "k", text: "applied " }), h("code", { text: String(st.applied_version ?? "-") }),
        h("span", { class: "k", text: "  latest " }), h("code", { text: String(st.latest_version ?? "-") }),
        behind ? h("span", { class: "warn", text: "  (behind)" }) : null),
      st.sdk_version ? h("span", {}, h("span", { class: "k", text: "sdk " }), String(st.sdk_version)) : null),
    ...(Array.isArray(st.pending_restart) ? st.pending_restart : []).map((c) =>
      h("div", { class: "warn", text: `${c}: restart pending — waiting for the service to allow it` })),
    ...Object.entries(isObj(st.errors) ? st.errors : {}).map(([c, m]) =>
      h("div", { class: "bad", text: `${c}: ${m}` })));
}

setInterval(async () => {
  if (!state.service || !state.instance || document.hidden) return;
  const token = state.token;
  try {
    const d = await api(`/api/services/${enc(state.service)}?instance=${enc(state.instance)}`);
    if (token !== state.token) return;
    state.data.instances = d.instances;
    renderStrip();
  } catch (_) { /* transient */ }
}, 5000);

// ------------------------------------------------------------- component card
function sourceBadge(comp) {
  if (comp.source === "instance") return h("span", { class: "badge src-instance", text: `override for ${state.instance}` });
  return h("span", { class: `badge src-${comp.source}`, text: comp.source });
}

function makeCard(name, initial) {
  let comp = initial;
  const card = h("section", { class: "card", id: `card-${name}` });
  const instance = state.instance;

  function render() {
    const reg = new Registry();
    const errEl = h("div", { class: "card-error", role: "alert" });
    const markDirty = () => card.classList.add("dirty");
    const form = h("form", { novalidate: true, onsubmit: (e) => { e.preventDefault(); save(); } });
    const schema = comp.schema || {};
    const field = buildField(schema, clone(comp.value), { root: schema, path: [], name: comp.title, reg, onChange: markDirty });
    form.append(field.el);
    const msg = h("input", { type: "text", class: "msg", placeholder: "change message (optional)", maxlength: 200, "aria-label": "Change message" });
    const saveBtn = h("button", { type: "submit", class: "primary", text: instance ? `Save for ${instance}` : "Save" });
    const buttons = [saveBtn,
      h("button", { type: "button", text: "Reset form to default", onclick: () => { comp = { ...comp, value: clone(comp.default) }; render(); markDirty(); } })];
    if (comp.source === "instance") {
      buttons.push(h("button", { type: "button", class: "danger", text: "Remove override", onclick: () => put(null, "Removed override", reg, errEl) }));
    }
    const histBox = h("div", { class: "history", hidden: true });
    const histBtn = h("button", { type: "button", text: "History" });
    histBtn.addEventListener("click", () => {
      histBox.hidden = !histBox.hidden;
      if (!histBox.hidden) loadHistory(histBox);
    });
    card.replaceChildren(...[
      h("div", { class: "card-head" },
        h("h3", { text: comp.title }),
        h("span", { class: `badge ${comp.reload}`, text: comp.reload }),
        sourceBadge(comp)),
      comp.description ? h("p", { class: "card-desc", text: comp.description }) : null,
      h("div", { class: "card-body" }, form,
        instance && comp.source !== "instance" ? h("div", { class: "help", text: `Saving creates an override for ${instance}; other instances keep the service value.` }) : null),
      errEl,
      h("div", { class: "card-foot" }, msg, ...buttons, histBtn),
      histBox,
    ].filter(Boolean));
    card.classList.remove("dirty");

    async function save() {
      const errs = [];
      const value = field.get(errs);
      if (errs.length) {
        const rest = reg.show(errs);
        errEl.textContent = rest.map((e) => e.message).join("\n");
        toast("Fix the highlighted fields", true);
        return;
      }
      await put(value, "Saved", reg, errEl, msg.value.trim() || null);
    }

    async function loadHistory(box) {
      box.replaceChildren(h("div", { class: "dim", text: "Loading…" }));
      try {
        const rows = await api(`/api/services/${enc(state.service)}/components/${enc(name)}/history?instance=${enc(instance || "*")}`);
        if (!rows.length) { box.replaceChildren(h("div", { class: "dim", text: "No revisions yet." })); return; }
        box.replaceChildren(...rows.map((r) => {
          const tomb = r.value === null;
          return h("div", { class: "hist-item" },
            h("div", { class: "top" },
              h("span", { class: "mono", text: `#${r.id}` }),
              h("span", { title: absTime(r.created_at), text: relTime(r.created_at) }),
              h("span", { text: r.author ? `by ${r.author}` : "anonymous" }),
              h("span", { class: "grow", text: r.message || "" }),
              h("button", { type: "button", class: "small", text: "Restore",
                onclick: () => put(r.value, `Restored #${r.id}`, reg, errEl, `Restore of #${r.id}`) })),
            h("pre", { text: tomb ? "(override removed)" : JSON.stringify(r.value, null, 2) }));
        }));
      } catch (e) {
        box.replaceChildren(h("div", { class: "bad", text: `Failed to load history: ${e.message}` }));
      }
    }
  }

  async function put(value, okText, reg, errEl, message) {
    const q = instance ? `?instance=${enc(instance)}` : "";
    errEl.textContent = "";
    reg.clear();
    try {
      const author = (document.getElementById("author").value || "").trim() || null;
      comp = await api(`/api/services/${enc(state.service)}/components/${enc(name)}${q}`, {
        method: "PUT", headers: { "content-type": "application/json" },
        body: JSON.stringify({ value, author, message: message || null }),
      });
      const wasOpen = !card.querySelector(".history")?.hidden;
      render();
      if (wasOpen) card.querySelector(".card-foot button:last-child").click();
      toast(`${comp.title}: ${okText}`);
      // refresh instance list / lists in the background
      loadServices();
      api(`/api/services/${enc(state.service)}${q}`).then((d) => { state.data.instances = d.instances; }).catch(() => {});
    } catch (e) {
      const errors = e.body && Array.isArray(e.body.errors) ? e.body.errors : null;
      if (errors) {
        const rest = reg.show(errors);
        errEl.textContent = rest.map((x) => x.message).join("\n");
        toast("Server rejected the value", true);
      } else {
        errEl.textContent = `Save failed: ${e.body?.detail ? JSON.stringify(e.body.detail) : e.message}`;
        toast("Save failed", true);
      }
    }
  }

  render();
  return { el: card };
}

// -------------------------------------------------------------------- boot
const authorInput = document.getElementById("author");
authorInput.value = store("aero-config-author") || "";
authorInput.addEventListener("input", () => store("aero-config-author", authorInput.value));
window.addEventListener("hashchange", route);
route();

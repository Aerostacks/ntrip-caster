"""FastAPI application for the aero-config server."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from jsonschema import Draft202012Validator
from pydantic import BaseModel

from .store import SERVICE_LEVEL, Store, version_of

STATIC_DIR = Path(__file__).parent / "static"


class PutBody(BaseModel):
    value: Any = None
    author: str | None = None
    message: str | None = None


def _path(parts: Any) -> str:
    return ".".join(str(p) for p in parts)


def validation_errors(schema: Any, value: Any) -> list[dict[str, str]]:
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(value), key=lambda e: list(e.absolute_path))
    return [{"path": _path(e.absolute_path), "message": e.message} for e in errors]


def create_app(db_path: str) -> FastAPI:
    store = Store(db_path)
    app = FastAPI(title="aero-config", version="0.1.0a1")
    app.state.store = store

    def registration(service: str) -> dict[str, Any]:
        reg = store.get_registration(service)
        if reg is None:
            raise HTTPException(404, f"unknown service {service!r}")
        return reg

    def component_reg(reg: dict[str, Any], service: str, name: str) -> dict[str, Any]:
        comp = reg.get("components", {}).get(name)
        if comp is None:
            raise HTTPException(404, f"unknown component {service}.{name}")
        return comp

    def resolve(
        service: str, name: str, comp: dict[str, Any], instance: str | None
    ) -> dict[str, Any]:
        """Effective value + provenance of one component."""
        star = store.latest(service, name, SERVICE_LEVEL)
        service_value, source, revision_id = comp.get("default"), "default", None
        if star is not None and not star[2]:
            revision_id, service_value, source = star[0], star[1], "service"
        value = service_value
        if instance is not None and instance != SERVICE_LEVEL:
            inst = store.latest(service, name, instance)
            if inst is not None and not inst[2]:
                revision_id, value, source = inst[0], inst[1], "instance"
        return {
            "title": comp.get("title") or name,
            "description": comp.get("description"),
            "reload": comp.get("reload", "live"),
            "schema": comp.get("schema", {}),
            "default": comp.get("default"),
            "value": value,
            "source": source,
            "service_value": service_value,
            "revision_id": revision_id,
        }

    def effective_values(
        service: str, reg: dict[str, Any], instance: str | None
    ) -> dict[str, Any]:
        return {
            name: resolve(service, name, comp, instance)["value"]
            for name, comp in sorted(reg.get("components", {}).items())
        }

    def norm_instance(instance: str | None) -> str | None:
        return instance or None

    @app.get("/api/health")
    def health() -> dict[str, bool]:
        return {"ok": True}

    @app.post("/api/services/{service}/register")
    def register(service: str, body: dict[str, Any]) -> Any:
        if body.get("service", service) != service:
            raise HTTPException(422, "service name in body does not match URL")
        components = body.get("components")
        if not isinstance(components, dict):
            raise HTTPException(422, "'components' must be an object")
        for name, comp in components.items():
            if not isinstance(comp, dict) or "schema" not in comp:
                raise HTTPException(422, f"component {name!r} needs a 'schema'")
            try:
                Draft202012Validator.check_schema(comp["schema"])
            except Exception as exc:  # jsonschema.SchemaError
                raise HTTPException(
                    422, f"component {name!r} has an invalid schema: {exc}"
                ) from exc
        store.upsert_service(service, {**body, "service": service})

        incompatible: dict[str, list[str]] = {}
        for name, comp in components.items():
            levels = [SERVICE_LEVEL, *store.revision_instances(service)]
            for level in levels:
                rev = store.latest(service, name, level)
                if rev is None or rev[2]:
                    continue
                label = "service" if level == SERVICE_LEVEL else f"instance {level}"
                for err in validation_errors(comp["schema"], rev[1]):
                    where = f" at {err['path']}" if err["path"] else ""
                    incompatible.setdefault(name, []).append(
                        f"{label}: {err['message']}{where}"
                    )
        return {"ok": True, "incompatible": incompatible}

    @app.get("/api/services")
    def list_services() -> Any:
        return store.list_services()

    @app.get("/api/services/{service}")
    def get_service(service: str, instance: str | None = Query(None)) -> Any:
        reg = registration(service)
        instance = norm_instance(instance)
        return {
            "name": service,
            "registered_at": reg["_registered_at"],
            "components": {
                name: resolve(service, name, comp, instance)
                for name, comp in reg.get("components", {}).items()
            },
            "instances": store.list_instances(service),
        }

    @app.get("/api/services/{service}/config")
    def get_config(
        service: str, request: Request, instance: str | None = Query(None)
    ) -> Response:
        reg = registration(service)
        instance = norm_instance(instance)
        if instance is not None and instance != SERVICE_LEVEL:
            store.touch_instance(service, instance)
        components = effective_values(service, reg, instance)
        version = version_of(components)
        etag = f'"{version}"'
        inm = request.headers.get("if-none-match", "")
        tags = [t.strip().removeprefix("W/") for t in inm.split(",")]
        if etag in tags:
            return Response(status_code=304, headers={"ETag": etag})
        return JSONResponse(
            {"version": version, "components": components}, headers={"ETag": etag}
        )

    @app.put("/api/services/{service}/components/{component}")
    def put_component(
        service: str,
        component: str,
        body: PutBody,
        instance: str | None = Query(None),
    ) -> Any:
        reg = registration(service)
        comp = component_reg(reg, service, component)
        level = norm_instance(instance) or SERVICE_LEVEL
        if body.value is None:
            if level == SERVICE_LEVEL:
                return JSONResponse(
                    {
                        "errors": [
                            {
                                "path": "",
                                "message": "null is not allowed at the service level",
                            }
                        ]
                    },
                    status_code=422,
                )
        else:
            errors = validation_errors(comp.get("schema", {}), body.value)
            if errors:
                return JSONResponse({"errors": errors}, status_code=422)
        store.add_revision(
            service, component, level, body.value, body.author, body.message
        )
        return resolve(service, component, comp, None if level == "*" else level)

    @app.get("/api/services/{service}/components/{component}/history")
    def history(
        service: str, component: str, instance: str | None = Query(None)
    ) -> Any:
        reg = registration(service)
        component_reg(reg, service, component)
        return store.history(service, component, norm_instance(instance), limit=50)

    @app.post("/api/services/{service}/instances/{instance}/status")
    def post_status(service: str, instance: str, body: dict[str, Any]) -> Response:
        registration(service)
        if instance == SERVICE_LEVEL:
            raise HTTPException(422, "'*' is not a valid instance name")
        store.touch_instance(service, instance, body)
        return Response(status_code=204)

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    return app

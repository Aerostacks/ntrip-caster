"""SQLite persistence for the aero-config server."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from datetime import UTC, datetime
from typing import Any

SERVICE_LEVEL = "*"

SCHEMA = """
CREATE TABLE IF NOT EXISTS services (
    name TEXT PRIMARY KEY,
    registration TEXT NOT NULL,
    schema_hash TEXT,
    registered_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service TEXT NOT NULL,
    component TEXT NOT NULL,
    instance TEXT NOT NULL,
    value TEXT,
    author TEXT,
    message TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS revisions_lookup
    ON revisions (service, component, instance, id);
CREATE TABLE IF NOT EXISTS instances (
    service TEXT NOT NULL,
    instance TEXT NOT NULL,
    last_seen TEXT,
    status TEXT,
    PRIMARY KEY (service, instance)
);
"""


def now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def version_of(components: dict[str, Any]) -> str:
    return hashlib.sha256(canonical(components).encode()).hexdigest()[:16]


def _loads(text: str | None) -> Any:
    return None if text is None else json.loads(text)


class Store:
    """Thin sqlite wrapper; a single connection guarded by a lock."""

    def __init__(self, path: str) -> None:
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.executescript(SCHEMA)
            self._db.commit()

    def close(self) -> None:
        with self._lock:
            self._db.close()

    # -- services ---------------------------------------------------------
    def get_registration(self, service: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._db.execute(
                "SELECT registration, registered_at FROM services WHERE name=?",
                (service,),
            ).fetchone()
        if row is None:
            return None
        reg = json.loads(row["registration"])
        reg["_registered_at"] = row["registered_at"]
        return reg

    def upsert_service(self, service: str, registration: dict[str, Any]) -> None:
        with self._lock:
            self._db.execute(
                "INSERT INTO services(name, registration, schema_hash, registered_at)"
                " VALUES (?,?,?,?) ON CONFLICT(name) DO UPDATE SET"
                " registration=excluded.registration,"
                " schema_hash=excluded.schema_hash,"
                " registered_at=excluded.registered_at",
                (
                    service,
                    json.dumps(registration, ensure_ascii=False),  # keeps field order
                    registration.get("schema_hash"),
                    now_iso(),
                ),
            )
            self._db.commit()

    def list_services(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._db.execute(
                "SELECT name, registration, registered_at FROM services ORDER BY name"
            ).fetchall()
        out = []
        for row in rows:
            reg = json.loads(row["registration"])
            out.append(
                {
                    "name": row["name"],
                    "components": list(reg.get("components", {})),
                    "registered_at": row["registered_at"],
                    "instances": [
                        i["instance"] for i in self.list_instances(row["name"])
                    ],
                }
            )
        return out

    # -- revisions --------------------------------------------------------
    def latest(
        self, service: str, component: str, instance: str
    ) -> tuple[int, Any, bool] | None:
        """Latest revision at a level: (id, value, is_tombstone) or None."""
        with self._lock:
            row = self._db.execute(
                "SELECT id, value FROM revisions WHERE service=? AND component=?"
                " AND instance=? ORDER BY id DESC LIMIT 1",
                (service, component, instance),
            ).fetchone()
        if row is None:
            return None
        if row["value"] is None:
            return row["id"], None, True
        return row["id"], json.loads(row["value"]), False

    def add_revision(
        self,
        service: str,
        component: str,
        instance: str,
        value: Any,
        author: str | None,
        message: str | None,
    ) -> int:
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO revisions(service, component, instance, value, author,"
                " message, created_at) VALUES (?,?,?,?,?,?,?)",
                (
                    service,
                    component,
                    instance,
                    None if value is None else canonical(value),
                    author,
                    message,
                    now_iso(),
                ),
            )
            self._db.commit()
            return int(cur.lastrowid or 0)

    def history(
        self,
        service: str,
        component: str,
        instance: str | None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        sql = (
            "SELECT id, instance, value, author, message, created_at FROM revisions"
            " WHERE service=? AND component=?"
        )
        args: list[Any] = [service, component]
        if instance is not None:
            sql += " AND instance=?"
            args.append(instance)
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        return [
            {
                "id": r["id"],
                "instance": r["instance"],
                "value": _loads(r["value"]),
                "author": r["author"],
                "message": r["message"],
                "created_at": r["created_at"],
            }
            for r in rows
        ]

    def revision_instances(self, service: str) -> list[str]:
        with self._lock:
            rows = self._db.execute(
                "SELECT DISTINCT instance FROM revisions WHERE service=? AND"
                " instance != ?",
                (service, SERVICE_LEVEL),
            ).fetchall()
        return [r["instance"] for r in rows]

    # -- instances --------------------------------------------------------
    def touch_instance(
        self, service: str, instance: str, status: dict[str, Any] | None = None
    ) -> None:
        with self._lock:
            if status is None:
                self._db.execute(
                    "INSERT INTO instances(service, instance, last_seen) VALUES (?,?,?)"
                    " ON CONFLICT(service, instance) DO UPDATE SET"
                    " last_seen=excluded.last_seen",
                    (service, instance, now_iso()),
                )
            else:
                self._db.execute(
                    "INSERT INTO instances(service, instance, last_seen, status)"
                    " VALUES (?,?,?,?) ON CONFLICT(service, instance) DO UPDATE SET"
                    " last_seen=excluded.last_seen, status=excluded.status",
                    (service, instance, now_iso(), canonical(status)),
                )
            self._db.commit()

    def list_instances(self, service: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._db.execute(
                "SELECT instance, last_seen, status FROM instances WHERE service=?"
                " ORDER BY instance",
                (service,),
            ).fetchall()
        seen = {r["instance"] for r in rows}
        out = [
            {
                "instance": r["instance"],
                "last_seen": r["last_seen"],
                "status": _loads(r["status"]),
            }
            for r in rows
        ]
        for name in sorted(self.revision_instances(service)):
            if name not in seen:
                out.append({"instance": name, "last_seen": None, "status": None})
        out.sort(key=lambda i: i["instance"])
        return out

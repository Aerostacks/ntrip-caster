"""`aero-config` command line: print or register a service's schema."""

from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
from collections.abc import Sequence

from ._client import TRANSPORT_ERRORS, ServerClient
from ._model import ConfigError
from ._service import Service


def _load_service(target: str) -> Service[object]:
    module, _, attr = target.partition(":")
    if not module or not attr:
        raise ConfigError(f"expected module:attr, got {target!r}")
    sys.path.insert(0, os.getcwd())
    try:
        obj = getattr(importlib.import_module(module), attr)
    except (ImportError, AttributeError) as e:
        raise ConfigError(f"cannot load {target!r}: {e}") from e
    if not isinstance(obj, Service):
        raise ConfigError(f"{target!r} is not a Service instance")
    return obj


def main(argv: Sequence[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="aero-config")
    sub = p.add_subparsers(dest="cmd", required=True)
    schema = sub.add_parser("schema", help="print the registration payload")
    schema.add_argument("target", metavar="module:attr")
    reg = sub.add_parser("register", help="POST the registration payload")
    reg.add_argument("target", metavar="module:attr")
    reg.add_argument("--url", default=os.environ.get("AERO_CONFIG_URL"))
    args = p.parse_args(argv)
    try:
        svc = _load_service(args.target)
        payload = svc.describe()
        if args.cmd == "schema":
            print(json.dumps(payload, indent=2))
            return 0
        if not args.url:
            raise ConfigError("--url (or AERO_CONFIG_URL) is required")
        resp = ServerClient(args.url, svc.timeout).register(payload)
    except ConfigError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    except TRANSPORT_ERRORS as e:
        print(f"error: registration failed: {e}", file=sys.stderr)
        return 1
    print(json.dumps(resp, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""The `Service[T]` runtime: load, poll, apply, restart, report."""

from __future__ import annotations

import dataclasses
import logging
import os
import signal
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, cast

from pydantic import ValidationError

from ._cache import Cache
from ._client import TRANSPORT_ERRORS, ServerClient
from ._model import (
    Component,
    ConfigError,
    Reload,
    describe_service,
    introspect,
    seed_values,
)

__all__ = ["ConfigError", "InstanceStatus", "Restart", "Service"]

SDK_VERSION = "0.1.0a1"
log = logging.getLogger("aero_config")


def _default_restart() -> None:
    """Ask the container runtime (or supervisor) to restart us."""
    pid = 1 if os.path.exists("/.dockerenv") else os.getpid()
    os.kill(pid, signal.SIGTERM)


@dataclass
class Restart:
    """When and how to apply pending RESTART components."""

    ready: Callable[[], bool] = lambda: True
    action: Callable[[], None] | None = None


@dataclass
class InstanceStatus:
    """Snapshot reported to the server after every poll."""

    service: str
    instance: str
    applied_version: str | None = None
    latest_version: str | None = None
    source: str = "seed"
    pending_restart: list[str] = field(default_factory=list)
    errors: dict[str, str] = field(default_factory=dict)
    sdk_version: str = SDK_VERSION
    reported_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


class Service[T]:
    """Typed, offline-first config for one service instance."""

    def __init__(
        self,
        name: str,
        root: type[T],
        *,
        instance: str = "default",
        url: str | None = None,
        cache_dir: str | os.PathLike[str] | None = None,
        seed: T | None = None,
        restart_when: Restart | None = None,
        poll_interval: float = 30.0,
        timeout: float = 2.0,
    ):
        self.name = name
        self.instance = instance
        self.poll_interval = poll_interval
        self.timeout = timeout
        self._root = root
        self._seed = seed
        self._components: dict[str, Component] = introspect(root)
        self._seed_values = seed_values(self._components, seed)
        self._restart = restart_when or Restart()
        self._client = ServerClient(url, timeout) if url else None
        self._cache = Cache(cache_dir, name, instance) if cache_dir else None
        self._cache_components: dict[str, Any] = {}

        self._lock = threading.RLock()
        self._values: dict[str, Any] = {}
        self._current: T | None = None
        self._pending: set[str] = set()
        self._restart_fired = False
        self._status = InstanceStatus(name, instance)
        self._subs: list[tuple[Callable[[T], Any], Callable[[Any], None]]] = []

        self._registered = False
        self._offline = False
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- public API ---------------------------------------------------------

    def load(self) -> T:
        """Resolve config (server, then cache, then seed) without blocking long."""
        sources: list[dict[str, Any]] = []
        source, version = "seed", None
        fetched = self._fetch(None)
        if fetched is not None:
            version, raw = fetched
            sources.append(raw)
            source = "server"
        if self._cache is not None:
            cached = self._cache.read()
            if cached is not None:
                self._cache_components = cached[1]
                if fetched is None:
                    version, source = cached[0], "cache"
                sources.append(cached[1])
        values, raws, errors = self._resolve(sources, self._seed_values)
        if fetched is not None:
            self._write_cache(version, raws)
        with self._lock:
            self._values = values
            self._current = self._build(values)
            self._pending.clear()
            self._status.source = source
            self._status.applied_version = version
            self._status.latest_version = fetched[0] if fetched else None
            self._status.errors = errors
            return self._current

    @property
    def current(self) -> T:
        """The config currently applied (loads lazily on first access)."""
        with self._lock:
            current = self._current
        return current if current is not None else self.load()

    def on_change[C](
        self, select: Callable[[T], C], callback: Callable[[C], None]
    ) -> None:
        """Call `callback(select(new))` when a LIVE change alters the selection."""
        with self._lock:
            self._subs.append((select, callback))

    def describe(self) -> dict[str, Any]:
        """The registration payload."""
        return describe_service(self.name, self._root, self._seed)

    def register(self) -> Any:
        """POST the schema to the server; raises `ConfigError` on failure."""
        if self._client is None:
            raise ConfigError("no server url configured")
        try:
            resp = self._client.register(self.describe())
        except TRANSPORT_ERRORS as e:
            raise ConfigError(f"registration failed: {e}") from e
        self._registered = True
        if isinstance(resp, dict) and resp.get("incompatible"):
            log.warning(
                "stored values incompatible with schema: %s", resp["incompatible"]
            )
        return resp

    def status(self) -> InstanceStatus:
        with self._lock:
            return dataclasses.replace(
                self._status,
                pending_restart=sorted(self._pending),
                errors=dict(self._status.errors),
                reported_at=datetime.now(UTC).isoformat(),
            )

    def start(self) -> None:
        """Start the daemon poll thread (no-op when there is no server url)."""
        if self._client is None or (self._thread and self._thread.is_alive()):
            return
        if self._current is None:
            self.load()
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            args=(self._stop,),
            name=f"aero-config-{self.name}",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the poll thread promptly."""
        self._stop.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(self.timeout + 1.0)

    # -- internals ----------------------------------------------------------

    def _build(self, values: dict[str, Any]) -> T:
        return cast(Any, self._root)(**values)

    def _fetch(self, etag: str | None) -> tuple[str, dict[str, Any]] | None:
        """Server fetch; None if offline or unchanged. Logs once per outage."""
        if self._client is None:
            return None
        try:
            res = self._client.get_config(self.name, self.instance, etag)
        except TRANSPORT_ERRORS as e:
            (log.debug if self._offline else log.warning)(
                "config server unavailable (%s): %s", self._client.base_url, e
            )
            self._offline = True
            return None
        if self._offline:
            log.info("config server reachable again")
        self._offline = False
        return res

    def _resolve(
        self, sources: list[dict[str, Any]], fallback: dict[str, Any]
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, str]]:
        """Per component: first source that validates, else `fallback`."""
        values: dict[str, Any] = {}
        raws: dict[str, Any] = {}
        errors: dict[str, str] = {}
        for name, comp in self._components.items():
            for raw in sources:
                if name not in raw:
                    continue
                try:
                    values[name] = comp.adapter.validate_python(raw[name])
                except ValidationError as e:
                    errors[name] = str(e)
                    log.warning("invalid value for component %r: %s", name, e)
                else:
                    raws[name] = raw[name]
                    break
            else:
                values[name] = fallback[name]
        return values, raws, errors

    def _write_cache(self, version: str | None, raws: dict[str, Any]) -> None:
        """Cache accepted raws, keeping the old entry for rejected components."""
        if self._cache is None:
            return
        merged = {**self._cache_components, **raws}
        self._cache.write(version, merged)
        self._cache_components = merged

    def _run(self, stop: threading.Event) -> None:
        while not stop.is_set():
            self._tick()
            if stop.wait(self.poll_interval):
                break

    def _tick(self) -> None:
        if not self._registered:
            try:
                self.register()
            except ConfigError as e:
                log.debug("%s (will retry)", e)
        try:
            self._poll_once()
        except Exception:
            log.exception("config poll failed")
        self._maybe_restart()
        self._report()

    def _poll_once(self) -> None:
        with self._lock:
            etag = self._status.latest_version
        fetched = self._fetch(etag)
        if fetched is None:
            return
        version, raw = fetched
        with self._lock:
            old = self.current
            old_values = dict(self._values)
            values, raws, errors = self._resolve([raw], old_values)
            for name, comp in self._components.items():
                if name in errors:
                    continue
                if values[name] == old_values[name]:
                    self._pending.discard(name)
                elif comp.policy.reload is Reload.RESTART:
                    self._pending.add(name)
                    self._restart_fired = False
                else:
                    self._values[name] = values[name]
            new = self._build(self._values)
            self._current = new
            self._status.latest_version = version
            self._status.errors = errors
            self._status.source = "server"
            if not self._pending:
                self._status.applied_version = version
            subs = list(self._subs)
        self._write_cache(version, raws)
        self._notify(subs, old, new)

    def _notify(
        self,
        subs: list[tuple[Callable[[T], Any], Callable[[Any], None]]],
        old: T,
        new: T,
    ) -> None:
        for select, callback in subs:
            try:
                before, after = select(old), select(new)
                if before != after:
                    callback(after)
            except Exception:
                log.exception("on_change subscription failed")

    def _maybe_restart(self) -> None:
        with self._lock:
            if not self._pending or self._restart_fired:
                return
        try:
            if not self._restart.ready():
                return
        except Exception:
            log.exception("restart ready() failed")
            return
        with self._lock:
            self._restart_fired = True
        log.info("applying pending restart: %s", sorted(self._pending))
        try:
            (self._restart.action or _default_restart)()
        except Exception:
            log.exception("restart action failed")
            with self._lock:
                self._restart_fired = False

    def _report(self) -> None:
        if self._client is None:
            return
        try:
            self._client.post_status(self.name, self.instance, self.status().to_dict())
        except TRANSPORT_ERRORS as e:
            log.debug("status report failed: %s", e)

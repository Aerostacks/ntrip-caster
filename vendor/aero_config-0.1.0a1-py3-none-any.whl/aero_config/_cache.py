"""Atomic last-known-good config cache."""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

log = logging.getLogger("aero_config")


class Cache:
    """`<dir>/<service>.<instance>.json` holding `{"version", "components"}`."""

    def __init__(self, directory: str | os.PathLike[str], service: str, instance: str):
        safe = re.sub(r"[^\w.-]", "_", f"{service}.{instance}")
        self.path = Path(directory) / f"{safe}.json"

    def read(self) -> tuple[str | None, dict[str, Any]] | None:
        """Return `(version, raw components)` or None if missing/corrupt."""
        try:
            data = json.loads(self.path.read_text())
            comps = data["components"]
            if not isinstance(comps, dict):
                raise TypeError("components is not an object")
            return data.get("version"), comps
        except FileNotFoundError:
            return None
        except (OSError, ValueError, KeyError, TypeError) as e:
            log.warning("ignoring unreadable cache %s: %s", self.path, e)
            return None

    def write(self, version: str | None, components: dict[str, Any]) -> None:
        """Write atomically (tmp + replace); failures are logged, never raised."""
        tmp = self.path.with_name(f"{self.path.name}.{os.getpid()}.tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(json.dumps({"version": version, "components": components}))
            os.replace(tmp, self.path)
        except OSError as e:
            log.warning("cannot write cache %s: %s", self.path, e)

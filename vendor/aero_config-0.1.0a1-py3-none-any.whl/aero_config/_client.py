"""Minimal urllib transport for the aero-config server."""

from __future__ import annotations

import http.client
import json
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import quote, urlencode

TRANSPORT_ERRORS = (OSError, ValueError, http.client.HTTPException)


class ServerClient:
    """Blocking JSON client. Raises one of `TRANSPORT_ERRORS` on any failure."""

    def __init__(self, base_url: str, timeout: float = 2.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, Any]:
        data = None if body is None else json.dumps(body).encode()
        hdrs = {"Accept": "application/json", **(headers or {})}
        if data is not None:
            hdrs["Content-Type"] = "application/json"
        req = urllib.request.Request(
            self.base_url + path, data=data, method=method, headers=hdrs
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return resp.status, (json.loads(raw) if raw else None)
        except urllib.error.HTTPError as e:
            if e.code == 304:
                return 304, None
            raise

    def get_config(
        self, service: str, instance: str, etag: str | None
    ) -> tuple[str, dict[str, Any]] | None:
        """Fetch `(version, raw components)`; None when unchanged (304)."""
        path = f"/api/services/{quote(service, safe='')}/config?" + urlencode(
            {"instance": instance}
        )
        headers = {"If-None-Match": f'"{etag}"'} if etag else None
        status, body = self._request("GET", path, headers=headers)
        if status == 304:
            return None
        if not (
            isinstance(body, dict)
            and isinstance(body.get("components"), dict)
            and isinstance(body.get("version"), str)
        ):
            raise ValueError("malformed config response")
        return body["version"], body["components"]

    def post(self, path: str, payload: Any) -> Any:
        """POST JSON and return the decoded response body (None if empty)."""
        return self._request("POST", path, payload)[1]

    def register(self, payload: dict[str, Any]) -> Any:
        return self.post(
            f"/api/services/{quote(payload['service'], safe='')}/register", payload
        )

    def post_status(self, service: str, instance: str, status: dict[str, Any]) -> None:
        svc, inst = quote(service, safe=""), quote(instance, safe="")
        path = f"/api/services/{svc}/instances/{inst}/status"
        self.post(path, status)
